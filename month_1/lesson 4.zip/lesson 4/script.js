// const salaries = {
//     arsen: 100,
//     karen: 450,
//     srbuhi: 230,
//     ani: 700,
// }

// for (let key in salaries) {
//     sum = sum + salaries[key];
// }

// console.log(sum)

// const array = [1, 2, 3, 4, 5, 12, 34, 44]

// let sum = 0;
// for (let item = 0; item < array.length; item++) {
//     sum = sum + array[item]
// }

// console.log(sum);


// functianer
// function hashvelBoloriGumare() {
//     let sum = 0;
//     for (let key in salaries) {
//         sum = sum + salaries[key];
//     }

//     return sum;
// }

// let portman1 = hashvelBoloriGumare()

// console.log('portman1', portman1)


// Fuckciai argumentner
// function bazmapatkel(tiv1, tiv2) { 
//     return tiv1 * tiv2;
// }

// console.log(bazmapatkel(2))

// function gumarel(tiv1, tiv2) { 
//     return tiv1, tiv2;
// }

// console.log(gumarel(3, 5))

// function hanum(tiv1, tiv2) {
//     return tiv1 - tiv2;
// }

// function bajanel(tiv1, tiv2) {
//     return tiv1 / tiv2;
// }

// const erkarutyun = bazmapatkel(3, 5);
// const lenutyubn = gumarel(2, 6);
// const boy = hanum(56, 4);
// const caval = bajanel(4, 2);
// console.log(caval);

// function barevel(name) {
//     return 'Barev ' + name + ' jan!';
// }

// console.log(barevel('Ashot'))
// console.log(barevel('Karen'))
// console.log(barevel('Hasmik'))

// function vostikan(kaskacyaliAnun) {
//     const goghiAnun = 'Gegham';

//     if (kaskacyaliAnun === goghiAnun) {
//         console.log('Ara brnvecir!');
//     } else {
//         console.log(kaskacyaliAnun + ' gogh chi :D')
//     }
// }

// console.log(vostikan('Ashot'))
// console.log(vostikan('Karen'))
// console.log(vostikan('Vazgen'))
// console.log(vostikan('Gegham'))