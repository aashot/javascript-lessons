/// Orinak 1

// let counter = 0;
// const numbersInterval = setInterval(function () {
//     counter += 1;
//     console.log(counter);
// }, 2000);

// numbersInterval;

/// Orinak 2
// const time = document.getElementById('date');
// const stopBtn = document.getElementById('stop');

// const timeInterval = setInterval(setTimer, 1000);

// function setTimer() {
//     const date = new Date();
//     time.innerText = date.toLocaleTimeString();
// }

// function stopTimer() {
//     clearInterval(timeInterval)
// }

// stopBtn.onclick = function() {
//     stopTimer();
// }


// const backgroundInterval = setInterval(changeBackground, 500);

// function changeBackground() {
//     const body = document.body;
//     body.style.backgroundColor = body.style.backgroundColor === "yellow" 
//         ? "pink"
//         : "yellow";
// }

// 1. stexcel guyneri zangvac
// 2. vercnel ayd zangvacic random guyn
// 3. poxel body i guyne random guynov
// 4. poxel guyne intervalov

// const colors = ['red', '#5c82df', 'black', '#bbbb4f', '#3ea72a', '#4d1f7d', '#21b656', '#eda90a', 'aqua', '#ff77f2'];

// function getRandomColor() {
//     const index = Math.floor(Math.random() * colors.length);
//     return colors[index];
// }

// function setBodyBackground() {
//     const body = document.body;
//     body.style.backgroundColor = getRandomColor();
// }

// const backgroundInterval = setInterval(setBodyBackground, 300);


// orinak 4

const images = [
    'https://media.istockphoto.com/photos/yerevan-capital-of-armenia-in-front-of-mt-ararat-picture-id1144776438?b=1&k=20&m=1144776438&s=170667a&w=0&h=27PSjM3Nobev4Lz26rF-z0Rgzwndhueux-FKpUqVRQc=',
    'https://image.shutterstock.com/image-photo/mountains-under-mist-morning-amazing-260nw-1725825019.jpg',
    'https://images.pexels.com/photos/302743/pexels-photo-302743.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
]

